#ifndef _BLE_UTILS_H_
#define _BLE_UTILS_H_
#include "shell.h"

typedef uint8_t deviceId_t;
#define DEBUG_BLE_OTA 1

#endif
