#include "atmosphere_variantSetup.h"

void ATMO_PLATFORM_VariantSetup()
{
    return;
}
